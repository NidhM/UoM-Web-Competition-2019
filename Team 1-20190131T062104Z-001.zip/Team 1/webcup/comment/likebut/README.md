howCode's PHP Like Button Script
================================

This is the source code for howCode's PHP like button script. To get it working you just need to create your database and run the phplikes.sql file.

You can watch the video that accompanies this source code here: https://youtu.be/dfxigz3Idoc
